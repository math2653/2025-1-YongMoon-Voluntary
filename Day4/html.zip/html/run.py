from flask import Flask, render_template, request, redirect, url_for, jsonify
from datetime import datetime

app = Flask(__name__)

posts = []
messages = []

@app.route('/')
def home():
    return render_template('home.html', active='home')

@app.route('/career')
def career():
    return render_template('career.html', active='career')

@app.route('/tmi')
def tmi():
    return render_template('tmi.html', active='tmi')

@app.route('/board')
def board():
    return render_template('board.html', posts=posts, active='board')

@app.route('/board/post', methods=['POST'])
def post_message():
    author = request.form['author']
    content = request.form['content']
    posts.insert(0, {
        'id': len(posts) + 1,
        'author': author,
        'content': content,
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M')
    })
    return redirect(url_for('board'))

@app.route('/chat')
def chat():
    return render_template('chat.html', active='chat')

@app.route('/chat/send', methods=['POST'])
def send_chat():
    user = request.form.get('user')
    message = request.form.get('message')
    if user and message:
        messages.append({
            'user': user,
            'message': message,
            'timestamp': datetime.now().strftime('%H:%M')
        })
    return jsonify(messages)

if __name__ == '__main__':
    app.run(debug=True)
